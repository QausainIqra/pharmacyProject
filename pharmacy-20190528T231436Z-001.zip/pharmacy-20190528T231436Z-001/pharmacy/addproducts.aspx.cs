﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pharmacy
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
                this.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
                if (Request.QueryString["id"] == null)
                {
                    btnupdate.Visible = false;

                    headmessage.Text = "Add a product";
                    using (var db = new pharmacyEntities())
                    {
                        var query = db.getallcategories().ToList();
                        ddl.DataSource = query;
                        ddl.DataBind();

                       
                    }
                }
                else if (Request.QueryString["id"] != null)
                {
                    btnadd.Visible = false;
                    int id = Convert.ToInt32(Request.QueryString["id"]);
                    headmessage.Text = "update a product";

                    using (var db = new pharmacyEntities())
                    {
                        //first way
                        //productsInfo p = db.productsInfoes.FirstOrDefault(v => v.id == id);

                        //name.Text = p.id.ToString();
                        //price.Text = p.pprice;
                        //second way
                        var query = db.getsingleproductInfo(id).ToList();
                        name.Text = query[0].pname;
                        price.Text = query[0].pprice;
                        desc.Text = query[0].pdesc;
                        quantity.Text = query[0].pquantity;
                        manufacturer.Text= query[0].pmanufacturer;
                        ddl.SelectedValue = query[0].pcategory;
                        expirydate.Text = query[0].pdoe;
                        productimage.DataSource = query;
                        productimage.DataBind();
                        var que = db.getallcategories().ToList();
                        ddl.DataSource = que;
                        ddl.DataBind();


                    }
                }
            }

        
        protected void Unnamed_Click(object sender, EventArgs e)
        {
                
                using (var db = new pharmacyEntities())
                {
                
                    productsInfo a = new productsInfo();
                    a.pname = name.Text;
                    a.pprice = price.Text;
                    a.pdesc = desc.Text;
                    if (image.HasFile)
                    {
                        image.SaveAs(Server.MapPath("client/img/"+image.FileName));
                    }
                   
                        a.pimage = image.FileName;
                        a.pcategory = ddl.SelectedValue;
                        a.pdoe = expirydate.Text;
                        a.pquantity = quantity.Text;
                        a.pmanufacturer = manufacturer.Text;
                        //a.pmanufacturer = ddl2.SelectedValue;
                        db.productsInfoes.Add(a);
                        db.SaveChanges();

                        Response.AddHeader("REFRESH", "2;URL=addproducts.aspx");
                        message.Text = "Product has been added";

                    }
                
            
   
        }

        protected void Unnamed_Click1(object sender, EventArgs e)
        {
            
            int id = Convert.ToInt32(Request.QueryString["id"]);
            using (var db = new pharmacyEntities())
            {
                // productsInfo a = db.productsInfoes.FirstOrDefault(v => v.id == id);
                //a.pname = name.Text;
                //a.pprice = price.Text;
                //a.pdesc = desc.Text;
                //a.pmanufacturer = manufacturer.Text;
                //a.pdoe = expirydate.Text;
                // a.pcategory = ddl.SelectedValue;
                //a.pimage = image.FileName;
                //a.pquantity = quantity.Text;
                //image.SaveAs(Server.MapPath("client/img/" + image.FileName));

                var q = db.updateitem(id, name.Text, price.Text, desc.Text, image.FileName, ddl.SelectedValue, expirydate.Text, quantity.Text, manufacturer.Text);

                db.SaveChanges();
                Response.Redirect("viewproducts.aspx");
            }
            }
        
    }
}