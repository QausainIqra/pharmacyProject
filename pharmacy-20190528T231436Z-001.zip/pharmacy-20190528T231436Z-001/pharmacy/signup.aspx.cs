﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pharmacy
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
        }

        protected void Unnamed_Click(object sender, EventArgs e)
        {
            using (var db = new pharmacyEntities())
            {
                usersInfo obj = new usersInfo();
                obj.name = uname.Text;
                obj.email = email.Text;
                obj.password = password.Text;
                obj.phoneno = pnumber.Text;
                obj.age = Convert.ToInt32(age.Text);
                db.usersInfoes.Add(obj);
                db.SaveChanges();
                lbl.Text="Signed up successfully";
                Response.Redirect("home.aspx");     
            }
        }
    }
}