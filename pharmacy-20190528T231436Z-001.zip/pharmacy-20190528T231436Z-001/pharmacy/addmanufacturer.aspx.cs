﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pharmacy
{
    public partial class addmanufacturers : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["id"] == null) {
                headmessage.Text = "enter manufacturer details";
            }
            if (!(Request.QueryString["id"] == null))  {
                headmessage.Text = "Update your record";
                var id = Convert.ToInt32(Request.QueryString["id"]);
                using (var db = new pharmacyEntities()) {
                    
                    var query = db.getallmanufacturer(id).ToList();
                    txtmname.Text = query[0].mname;
                    txtmphoneno.Text = query[0].mphoneno;
                    txtmaddress.Text = query[0].maddress;

                }
            }
        }
        protected void Unnamed_Click(object sender, EventArgs e)
        {
            if (Request.QueryString["id"] == null)
            {
                using (var db = new pharmacyEntities())
                {
                    tblmanufacturer a = new tblmanufacturer();
                    a.mname = txtmname.Text;
                    a.mphoneno = txtmphoneno.Text;
                    a.maddress = txtmaddress.Text;
                    db.tblmanufacturers.Add(a);
                    db.SaveChanges();
                    Response.AddHeader("REFRESH", "2;URL=addmanufacturer.aspx");
                    message.Text = "Values has been added successully";
                }
            }
            if (!(Request.QueryString["id"] == null))  {
                var id = Convert.ToInt32(Request.QueryString["id"]);
                using (var db = new pharmacyEntities())
                {
                    tblmanufacturer a = db.tblmanufacturers.FirstOrDefault(v => v.id == id);
                    a.mname = txtmname.Text;
                    a.mphoneno = txtmphoneno.Text;
                    a.maddress = txtmaddress.Text;
                    //productsInfo a = db.productsInfoes.FirstOrDefault(v => v.id == id);
                    //var que = db.updatemanufacturer(id, txtmname.Text, txtmphoneno.Text, txtmaddress.Text);
                    db.SaveChanges();
                    Response.Redirect("viewmanufacturers.aspx");
                }
            }
        }
    }
}