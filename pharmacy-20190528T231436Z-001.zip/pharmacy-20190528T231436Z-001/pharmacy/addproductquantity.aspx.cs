﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pharmacy
{
    public partial class addproductquantity : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["id"] == null)
            {
                Response.Redirect("viewproducts.aspx");
            }
            using (var db = new pharmacyEntities())
            {
                int id = Convert.ToInt32(Request.QueryString["id"]);
                var query = db.getpreviousquantity(id);
                gv.DataSource = query;
                gv.DataBind();

            }

        }

        protected void btn_Click(object sender, EventArgs e)
        {
           int id = Convert.ToInt32(Request.QueryString["id"]);
           int val = Convert.ToInt32(quantity.Text);
            using (var db = new pharmacyEntities())
            {

                var query = db.incrementquantity(id, val);
                Response.Redirect("viewproducts.aspx");
            
                
                

                //var total = Convert.ToInt32(Convert.toInt32(query)+ quantity.Text);
                //Response.Write(total);
            }
        }
    }
}