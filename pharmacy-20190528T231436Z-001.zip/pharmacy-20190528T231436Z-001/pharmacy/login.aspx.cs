﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pharmacy
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        protected void Unnamed_Click(object sender, EventArgs e)
        {
            string em = email.Text;
            string ps = password.Text;
            using (var db = new pharmacyEntities())
            {

            //       var s = (from d in db.usersInfoes
            //         where d.email==em && d.password==ps
            //         select d).ToList();
            //if (s.Count() > 0)
            //{
            //    Session["userId"] = s[0].id;
            //    Session["Email"] = s[0].email;
            //    Session["name"] = s[0].name;
            //    Session.Timeout = 720;
            //    messsage.Text = "you have been logged in sueecceessfully</br>";
            //    Response.AddHeader("REFRESH", "5;URL=addproduct.aspx");
            //}
            //    
                //else
            //{
            //    messsage.Text = "Sorry wrong email or password";
            //}
              
                var query = db.dologin(em, ps).ToList();
                if (query.Count > 0)
                {
                    using (var database = new pharmacyEntities())
                    {
                        var que = database.getUsersinfo().ToList();
                        Response.Cookies["user"]["id"] = Convert.ToString(que[0].id);
                        Response.Cookies["user"]["name"] = que[0].name;
                        Response.Cookies["user"]["email"] = que[0].email;

                        Session["useremail"] = em;
                        Session["username"] = query[0].name;
                        Session.Timeout = 720;

                        Response.Redirect("empty.aspx");

                    }
                }

                else
                {
                    message.Text = "invalid email or password , try again";
                }

            }

        }
    }
}