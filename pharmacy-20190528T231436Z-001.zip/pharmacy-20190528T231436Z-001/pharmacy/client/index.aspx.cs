﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pharmacy.client
{
    public partial class home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        
            using(var db= new pharmacyEntities()) {
            var query =db.getProductsAllInformation();
            products.DataSource = query;
            name.DataSource = query;
            price.DataSource = query;
            price.DataBind();
            name.DataBind();
                products.DataBind();
               
               
                
            }

            }

        }
    }