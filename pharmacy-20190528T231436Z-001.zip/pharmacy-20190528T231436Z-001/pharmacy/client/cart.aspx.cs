﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace pharmacy.client
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["cart"] != null) {
                
                DataTable dt = (DataTable)Session["cart"];
                cart_data.DataSource = dt;
                cart_data.DataBind();
                int rows = dt.Rows.Count;
                int total = 0;
                for (int i=0; i < rows; i++)  {
                    int price = Convert.ToInt32(dt.Rows[i]["Price"]);
                    total = price + total;
                }
                lbl.Text = total + "  Rs";
                Session["total"] = total;
            }
            else
            {
                Response.Redirect("home.aspx");
            }

        }
        
        

        protected void cart_data_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int id =Convert.ToInt32(e.CommandArgument);
            if (e.CommandName == "delete")
            {
                DataTable dt = (DataTable)Session["cart"];
                //foreach(DataRow dr in dt.Rows)
                //{
                //    if (dr["id"].ToString() == Convert.ToString(id))
                //    {
                //        dr.Delete();
                //        dt.AcceptChanges();
                //    }
                //}
                var RowNum = Convert.ToInt32(e.CommandArgument.ToString()) - 1;
                DataRow dr = dt.Rows[RowNum];
                dr.Delete();
                
                //dt.Rows.Remove(Table.Rows[id]["id"]);
                Response.Redirect("cart.aspx");
            }

        }

        protected void btn_Click(object sender, EventArgs e)
        {
            Response.Redirect("checkout.aspx");
        }
    }
}