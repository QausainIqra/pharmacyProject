﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Xml;
namespace pharmacy.client
{
    public partial class checkout : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["cart"] == null)
            {

                Response.Redirect("home.aspx");
            }
            else
            {
                this.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;

                DataTable dt = (DataTable)Session["cart"];
                gv.DataSource = dt;
                gv.DataBind();
                
                lbtotal.Text = Session["total"].ToString();
                if (lbtotal.Text == "0")
                {
                    Response.Redirect("singleproduct.aspx");
                }
                Session["carttotal"] = lbtotal.Text;
            }
        }
       

        protected void btn_Click(object sender, EventArgs e)
        {
            using (var db = new pharmacyEntities()) {
                tblcostumer a = new tblcostumer();
                a.country = txtcountry.Text;
                a.fname = txtfname.Text;
                a.lname = txtlname.Text;
                a.state = txtstate.Text;
                a.town = txttown.Text ;
                a.address = txtaddress.Text;
                a.companyname = txtcname.Text;
                a.email = txtemail.Text;
                a.password = txtpassword.Text;
                a.postcode = txtpostcode.Text;
                a.number = txtphoneno.Text;
                a.note = txtnote.Text;
                db.tblcostumers.Add(a);
                db.SaveChanges();
                lblthankyou.Text = "thank you";
                Response.AddHeader("REFRESH", "3;URL=home.aspx");


            }
        }

        //protected void btnforxml_Click(object sender, EventArgs e)
        //{
        //    using (XmlWriter writer = XmlWriter.Create(Server.MapPath("bill.xml")))
        //    {
        //        writer.WriteStartElement("costumerinformation");
        //        writer.WriteStartElement("personalinfo");
        //        writer.WriteElementString("First_name", txtfname.Text);
        //        writer.WriteElementString("Last_name", txtlname.Text);
        //        writer.WriteElementString("phoneno", txtphoneno.Text);
        //        writer.WriteEndElement();
        //        writer.WriteStartElement("total");
        //        writer.WriteElementString("total", lbtotal.Text);
        //        writer.WriteEndElement();
        //        writer.WriteEndElement();
        //    }


        //}

        //protected void viewxml_Click(object sender, EventArgs e)
        //{
            
        //    Response.Redirect("bill.aspx");
        //}
    }
}