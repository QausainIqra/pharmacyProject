﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pharmacy.client
{
    public partial class home1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            using (var db = new pharmacyEntities())
            {
                var query = db.getProductsAllInformation();
                products.DataSource = query;
                products.DataBind();
                        
            }
        }

        protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
        {
        
        }

        protected void products_ItemCommand(object source, DataListCommandEventArgs e)
        {
           int id=Convert.ToInt32(e.CommandArgument);
          
            if (e.CommandName == "details")
            {
                Response.Redirect("singleproduct.aspx?id="+id);
            }
        }
    }
}