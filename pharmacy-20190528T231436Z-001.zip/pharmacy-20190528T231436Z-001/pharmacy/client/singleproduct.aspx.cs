﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace pharmacy.client
{
    public partial class single_product : System.Web.UI.Page
    {
 
        
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            int id = Convert.ToInt32(Request.QueryString["id"]);
            if (Request.QueryString["id"] == null)
            {
                Response.Redirect("home.aspx");
            }
            if (Request.QueryString["id"] != null)
            {
                using (var db = new pharmacyEntities())
                {
                    var query = db.getsingleproductInfo(id);
                    singleproductpic.DataSource = query;
                    singleproductpic.DataBind();
                    singleproductname.DataSource = query;
                    singleproductname.DataBind();
                    singleproductprice.DataSource = query;
                    singleproductprice.DataBind();
                    singleproductdesc.DataSource = query;
                    singleproductdesc.DataBind();
                    singleproductcategory.DataSource = query;
                    singleproductcategory.DataBind();
                    singleproductmanufacturer.DataSource = query;
                    singleproductmanufacturer.DataBind();
                    availablequantity2.DataSource = query;
                    availablequantity2.DataBind();
                    var query2 = db.getsingleproductInfo(id).ToList();
                    Session["quantity"] =Convert.ToInt32(query2[0].pquantity);
                }
            }
            
        }

        protected void Unnamed_Click(object sender, EventArgs e)
        {
            DataTable dt;
            if (Session["cart"] == null)
            {
                dt = new DataTable();
                DataColumn col1 = new DataColumn("id", typeof(int                                       ));
                ////add product id for change in quantity
                DataColumn col2 = new DataColumn("image", typeof(string));
                DataColumn col3 = new DataColumn("name", typeof(string));
                DataColumn col4 = new DataColumn("Price", typeof(string));
                DataColumn col5 = new DataColumn("quantity", typeof(string));
                DataColumn col6 = new DataColumn("perprice", typeof(string));
                dt.Columns.Add(col1);
                dt.Columns.Add(col2);
                dt.Columns.Add(col3);
                dt.Columns.Add(col4);
                dt.Columns.Add(col5);
                dt.Columns.Add(col6);
                //dt = new DataTable();
                //DataColumn col1 = new DataColumn("id", typeof(String));
                //DataColumn col2 = new DataColumn("name", typeof(string));




            }
            else
            {

                dt = (DataTable)Session["cart"];
            }
            if (Request.QueryString["id"] != null)
            {
                using(var db=new pharmacyEntities())
                {
                    int id=Convert.ToInt32(Request.QueryString["id"]);
                    var a = Convert.ToInt32(quantity.Text);
                    var query2 = db.updatequantity(id,a);
                    db.SaveChanges();
                    var query= db.getsingleproductInfo(id).ToList();
                DataRow dr;
                dr = dt.NewRow();
                dr["id"] = dt.Rows.Count + 1;
                dr["image"] = query[0].pimage;
                dr["name"] = query[0].pname;
                dr["quantity"] = quantity.Text;
                dr["perprice"] = query[0].pprice;
                dr["price"] = Convert.ToInt32(query[0].pprice) * Convert.ToInt32( quantity.Text);
                    dt.Rows.Add(dr);
                    Session["rows"] = dt.Rows.Count;
                Session["cart"] = dt;
                message.Visible = true;
                message.Text = "Added To Cart";
                Response.AddHeader("REFRESH", "0;URL=home.aspx");
                }
                
            }
           
        }
    }
}