﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pharmacy
{
    public partial class home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["email"] == null)
            {
                Response.Redirect("login.aspx");

            }
            

         
       }

        private void fill()
        {
            using (var db = new pharmacyEntities())
            {
                var query = db.getdata();
                gv.DataSource = query;
                gv.DataBind();

            }
        }
        protected void gv_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void gv_RowEditing(object sender, GridViewEditEventArgs e)
        {

        }

        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "delete")
            {
                Response.Redirect("signup.aspx?id=");
            }
            if (e.CommandName == "edit")
            {
               using(var db=new pharmacyEntities())
               {
                //var query = db.deleteitems;
                fill();
               }           }

                           }

        }
    }
