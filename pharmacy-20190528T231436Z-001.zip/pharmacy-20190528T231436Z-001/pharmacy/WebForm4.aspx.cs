﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pharmacy
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            label1.Text=Request.Cookies["users"]["id"];
            label1.Text = Request.Cookies["users"]["name"];
            label1.Text = Request.Cookies["users"]["email"];


        }
    }
}