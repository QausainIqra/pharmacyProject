﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pharmacy
{
    public partial class viewmanufacturer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            using (var db = new pharmacyEntities()){
                var query = db.getmanufacturersallinfo();
                gv.DataSource= query;
                gv.DataBind();
            }
        }

        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            var id = Convert.ToInt32(e.CommandArgument);
            if (e.CommandName == "edit")
            {
                Response.Redirect("addmanufacturer.aspx?id="+id);
            }
            if (e.CommandName == "delete")
            {

                using (var db = new pharmacyEntities())
                {
                    var query = db.deletemanufacturer(id);
                    Response.Redirect("viewmanufacturers.aspx");
                    
               
                }
            }
        }
        protected void gv_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void gv_RowEditing(object sender, GridViewEditEventArgs e)
        {

        }
    }
}