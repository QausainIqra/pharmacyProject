﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pharmacy
{
    public partial class viewproducts : System.Web.UI.Page
    {
        private void products()
        {
            using (var db = new pharmacyEntities())
            {
                var a = db.getProductsAllInformation();
                gv.DataSource = a;
                gv.DataBind();
  
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            products();

        }

        protected void gv_RowEditing(object sender, GridViewEditEventArgs e)
        {

        }

        protected void gv_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int idd= Convert.ToInt32(e.CommandArgument);
            //accepting id so that we can use it as a querystring and other operations check below 3 lines
            if (e.CommandName== "edit") {
                
                Response.Redirect("addproducts.aspx?id=" + idd);
            }
            if (e.CommandName== "delete") {
                using (var db = new pharmacyEntities()){
                    db.deleteitem(idd);
                   
                    products();
                }
            }
            if (e.CommandName == "editquantity")
            {

                Response.Redirect("addproductquantity.aspx?id="+idd);  
            }
        }
    }
}